package com.ntxcodes.co227projectbackend.repository;

import com.ntxcodes.co227projectbackend.model.GES;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GESRepository extends JpaRepository<GES,String> {

}
