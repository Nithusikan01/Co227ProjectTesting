package com.ntxcodes.co227projectbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Co227projectbackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
