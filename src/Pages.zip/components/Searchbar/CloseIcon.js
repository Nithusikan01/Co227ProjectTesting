import React from 'react';

const CloseIcon = () => {
  return (
    <i className="bi bi-x" />
  );
}

export default CloseIcon;
