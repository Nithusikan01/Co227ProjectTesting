import React from 'react';

const SearchIcon = () => {
  return (
    <i className="bi bi-search" />
  );
}

export default SearchIcon;
