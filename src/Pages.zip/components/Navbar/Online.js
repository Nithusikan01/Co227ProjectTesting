import React from 'react'

const Online = () => {
    return (
        <div className="sec__one">
            <h1> Online Shop </h1>
        </div>
    )
}

export default Online
