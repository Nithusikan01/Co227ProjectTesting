import React from 'react'

const About = () => {
       return (
              <div className="sec__one">
                     <h1> About </h1>
              </div>
       )
}

export default About
