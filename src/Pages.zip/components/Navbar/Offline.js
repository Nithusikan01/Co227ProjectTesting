import React from 'react'

const Offline = () => {
    return (
        <div className="sec__one">
            <h1> Offline Shop </h1>
        </div>
    )
}

export default Offline
