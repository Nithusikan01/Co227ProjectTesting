import React from 'react'

const Contact = () => {
       return (
              <div className="sec__one">
                     <h1> Contact </h1>
              </div>
       )
}

export default Contact
