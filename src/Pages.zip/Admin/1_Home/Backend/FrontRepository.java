package com.GES.General_Elective_Subjects.Repository;

import com.GES.General_Elective_Subjects.Model.Front;

import org.springframework.data.jpa.repository.JpaRepository;

public interface FrontRepository extends JpaRepository<Front,String> {
}
