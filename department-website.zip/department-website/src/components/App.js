import React from "react";
import './App.css';
import MainPage from "../Pages/Mainpage";


function App() {


  return (
    
  <>
      <MainPage/>
  </>

  );
}

export default App;
